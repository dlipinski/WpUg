const User = require('../models/user.js');
const mongoose = require('mongoose'), Schema = mongoose.Schema;

const AuctionSchema = mongoose.Schema({
    createtor: {type: Schema.Types.ObjectId, ref: 'User'},
    isBuyNow: Boolean,
    title: String,
    description: String,
    photo: String,
    price: Number,
    startDate: { type: Date, default: Date.now },
    endDate:  { type: Date, default: Date.now },
    ended:  { type: Boolean, default: false },
    auctioneers: [{type: Schema.Types.ObjectId, ref: 'User'}]
})

module.exports = mongoose.model('Auction',AuctionSchema);