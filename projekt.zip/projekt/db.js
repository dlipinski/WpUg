require('./models/auction');

module.exports = {
    'url' : 'mongodb://localhost/myDB'
}

